import React, { useState, useRef, useEffect } from "react";
import { Send, Paperclip, Sparkles, File, FileArchive, Image as ImageIcon, X, Menu, Plus, User } from "lucide-react";
import "./App.css";

// ATENÇÃO: troque essa URL pelo endereço real do seu backend (o kloup-backend
// que compila apps, ou seu proxy pra API da Anthropic). Chamar a API da
// Anthropic direto do app instalado no celular do usuário expõe sua chave —
// não faça isso em produção, sempre passe por um backend seu.
const API_URL = "https://SEU-BACKEND-AQUI.com/chat";

function iconForFile(name) {
  const ext = name.split(".").pop().toLowerCase();
  if (["png", "jpg", "jpeg", "gif", "webp", "svg"].includes(ext)) return <ImageIcon size={16} />;
  if (["apk", "zip", "rar", "7z"].includes(ext)) return <FileArchive size={16} />;
  return <File size={16} />;
}

function formatBytes(bytes) {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
}

export default function App() {
  const [user, setUser] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [attachments, setAttachments] = useState([]);
  const [loading, setLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const fileInputRef = useRef(null);
  const scrollRef = useRef(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  // Login Google real: use @capacitor-community/google-signin no app nativo,
  // ou Google Identity Services se preferir manter tudo em webview.
  function handleGoogleLogin() {
    setUser({ name: "Convidado Kloup", email: "convidado@kloup.app" });
  }

  function handleLogout() {
    setUser(null);
    setMessages([]);
  }

  function handleFileSelect(e) {
    const files = Array.from(e.target.files || []);
    files.forEach((file) => {
      const isText = /\.(txt|md|csv|json|js|py|html|css)$/i.test(file.name) && file.size < 200000;
      if (isText) {
        const reader = new FileReader();
        reader.onload = () => {
          setAttachments((prev) => [
            ...prev,
            { id: crypto.randomUUID(), name: file.name, size: file.size, textContent: reader.result },
          ]);
        };
        reader.readAsText(file);
      } else {
        setAttachments((prev) => [
          ...prev,
          { id: crypto.randomUUID(), name: file.name, size: file.size, textContent: null },
        ]);
      }
    });
    e.target.value = "";
  }

  function removeAttachment(id) {
    setAttachments((prev) => prev.filter((a) => a.id !== id));
  }

  async function sendMessage() {
    if (!input.trim() && attachments.length === 0) return;
    setLoading(true);

    const userMsg = { id: crypto.randomUUID(), role: "user", text: input, attachments };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput("");
    setAttachments([]);

    try {
      const response = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: newMessages }),
      });
      const data = await response.json();
      setMessages((prev) => [
        ...prev,
        { id: crypto.randomUUID(), role: "assistant", text: data.text || "Não consegui gerar uma resposta." },
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        { id: crypto.randomUUID(), role: "assistant", text: "Erro ao falar com o servidor do Kloup." },
      ]);
    } finally {
      setLoading(false);
    }
  }

  function handleKeyDown(e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  }

  if (!user) {
    return (
      <div className="login-screen">
        <div className="blob blob-a" />
        <div className="blob blob-b" />
        <div className="login-content">
          <div className="brand">
            <div className="logo"><Sparkles size={22} color="#fff" /></div>
            <span className="brand-name">Kloup</span>
          </div>
          <h1>Converse. Envie. Sem limites.</h1>
          <p>IA profissional com envio de qualquer tipo de arquivo, direto na conversa.</p>
          <button className="google-btn" onClick={handleGoogleLogin}>
            <svg width="18" height="18" viewBox="0 0 18 18">
              <path fill="#4285F4" d="M17.64 9.2c0-.64-.06-1.25-.16-1.84H9v3.48h4.84a4.14 4.14 0 0 1-1.8 2.72v2.26h2.9c1.7-1.57 2.68-3.87 2.68-6.62z" />
              <path fill="#34A853" d="M9 18c2.43 0 4.47-.8 5.96-2.18l-2.9-2.26c-.8.54-1.84.86-3.06.86-2.35 0-4.34-1.59-5.05-3.72H.96v2.33A9 9 0 0 0 9 18z" />
              <path fill="#FBBC05" d="M3.95 10.7A5.4 5.4 0 0 1 3.67 9c0-.59.1-1.17.28-1.7V4.97H.96A9 9 0 0 0 0 9c0 1.45.35 2.83.96 4.03l2.99-2.33z" />
              <path fill="#EA4335" d="M9 3.58c1.32 0 2.51.45 3.44 1.35l2.58-2.58C13.46.89 11.43 0 9 0A9 9 0 0 0 .96 4.97L3.95 7.3C4.66 5.17 6.65 3.58 9 3.58z" />
            </svg>
            Entrar com Google
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="app-shell">
      <div className={`sidebar ${sidebarOpen ? "open" : "closed"}`}>
        <div className="sidebar-header">
          <div className="logo small"><Sparkles size={16} color="#fff" /></div>
          <span className="brand-name">Kloup</span>
        </div>
        <button className="new-chat" onClick={() => setMessages([])}>
          <Plus size={16} /> Nova conversa
        </button>
        <div className="spacer" />
        <div className="user-card">
          <div className="avatar"><User size={16} /></div>
          <div className="user-info">
            <div className="user-name">{user.name}</div>
            <div className="user-email">{user.email}</div>
          </div>
          <button className="logout" onClick={handleLogout}>Sair</button>
        </div>
      </div>

      <div className="chat-area">
        <div className="topbar">
          <button className="icon-btn" onClick={() => setSidebarOpen((s) => !s)}><Menu size={18} /></button>
          <span className="topbar-label">Kloup — sem limite de mensagens</span>
        </div>

        <div className="messages" ref={scrollRef}>
          {messages.length === 0 && (
            <div className="empty-state">
              <Sparkles size={28} />
              <p>Envie uma mensagem ou anexe um arquivo (inclusive .apk) para começar.</p>
            </div>
          )}
          <div className="messages-inner">
            {messages.map((m) => (
              <div key={m.id} className={`message-row ${m.role}`}>
                <div className={`bubble ${m.role}`}>
                  {m.text}
                  {m.attachments?.length > 0 && (
                    <div className="attachment-chips">
                      {m.attachments.map((a) => (
                        <div key={a.id} className="chip">{iconForFile(a.name)} {a.name}</div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
            {loading && (
              <div className="message-row assistant">
                <div className="bubble assistant">Kloup está digitando…</div>
              </div>
            )}
          </div>
        </div>

        <div className="input-bar">
          <div className="input-inner">
            {attachments.length > 0 && (
              <div className="attachment-chips mb">
                {attachments.map((a) => (
                  <div key={a.id} className="chip outline">
                    {iconForFile(a.name)} {a.name}
                    <span className="chip-size">{formatBytes(a.size)}</span>
                    <button className="chip-remove" onClick={() => removeAttachment(a.id)}><X size={12} /></button>
                  </div>
                ))}
              </div>
            )}
            <div className="composer">
              <button className="icon-btn" onClick={() => fileInputRef.current?.click()}><Paperclip size={18} /></button>
              <input ref={fileInputRef} type="file" accept="*" multiple style={{ display: "none" }} onChange={handleFileSelect} />
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                rows={1}
                placeholder="Mensagem para a Kloup…"
              />
              <button className="send-btn" onClick={sendMessage} disabled={loading}><Send size={15} color="#fff" /></button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
