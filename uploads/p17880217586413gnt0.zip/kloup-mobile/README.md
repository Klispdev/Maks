# Kloup Mobile

App do Kloup empacotado com Capacitor pra virar `.apk` Android.

## Como gerar o .apk pelo GitHub (sem instalar nada no seu PC)

1. Crie um repositório novo no GitHub.
2. Suba o conteúdo deste zip pra ele (extraia e faça `git init`, `git add .`,
   `git commit -m "kloup mobile"`, `git push`) — ou use "Upload files" direto
   pela interface web do GitHub.
3. Vá na aba **Actions** do repositório. O workflow `Build APK` roda sozinho
   a cada push na branch `main` (ou clique em "Run workflow" pra rodar na
   hora).
4. Quando o workflow terminar (ícone verde ✅), abra a execução e baixe o
   artefato **kloup-apk** — dentro dele está o `app-debug.apk` pronto pra
   instalar no celular.

## Antes de subir: ajuste a URL do backend

Em `src/App.jsx`, troque:

```js
const API_URL = "https://SEU-BACKEND-AQUI.com/chat";
```

pelo endereço real do seu backend (o `kloup-backend` que já montamos, ou um
endpoint seu que fale com a API da Anthropic). Sem isso o app builda
normalmente, mas o chat não vai responder.

## Rodando localmente (opcional, se quiser testar antes de subir)

```bash
npm install
npm run build
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
```

O apk sai em `android/app/build/outputs/apk/debug/app-debug.apk`.

## Sobre o login com Google

O botão "Entrar com Google" está simulado. Para produção real num app
Android nativo, use o plugin `@capacitor-community/google-signin` com seu
próprio OAuth Client ID do Google Cloud Console.
